let prefix = `${client.guilds.cache.get(global.sistem.SUNUCU.GUILD).emojiyiBul(emojiler.no_cartel)}`

module.exports = {
    prefix,
    yetersiz:      `Kişinin yetkili rolü bulunamadı.`,
    bot:           `Bir kullanıcı etiketlemelisin!`,
    üye:           `Bir kullanıcı etiketlemelisin!`,
    sebep:         `Bir sebep belirtmelisin!`,
    yetkiust:      `Kendinden üstün kişilere işlem uygulayamazsın.`,
    dokunulmaz:    `Kendimden üstün kişilere işlem uygulayamam.`,
    kayıtlı:       `Kayıtlı olmayan bir kişi belirtmelisin!`,
    kayıtsız:      `Kayıtlı olan bir kişi belirtmelisin!`,
    kendi:         `Kendine işlem uygulayamazsın.`,
    bulunamadi:    `Belirttiğin bilgiyi sunucuda bulamadım.`,
    üyeyok:        `Belirttiğin kişiyi sunucuda bulamadım.`,
    yenihesap:     `Belirttiğin kişinin hesabı Şüpheli olduğu görüntülendi.`,
    cezaliuye:     `Belirttiğin kişi sunucu içinde Cezalı olarak görüntülendi.`,
    yetersizyaş:   `Belirttiğin kişinin yaşı yeterli olmadığı için işlem yapamazsın!`,
    argümandoldur: `Lütfen argüman belirt ve tekrar dene.`,
    taglıalım:     `Belirttiğin kişinin üzerinde sunucu tagı olmadığından işlem yapmadım.`, 
    isimapi:       `Belirttiğin isim 32 karakteri aşdığı için işlem yapmadım.`,
    cezavar:       `Belirttiğin kişinin aktif cezası bulunduğundan işlem yapmadım.`,
    cezayok:       `Belirttiğin kişinin aktif bir ceza verisine ulaşamadım.`,
    yetkilinoban:  `Belirttiğin kişi yetkili olduğundan işlem yapamadım.`,
    yasaklamayok:  `Sunucu içerisinde yasaklama verisi bulamadım.`,
    ayarlamayok:    ``,
    notSetup: ``,
    data: `Belirttiğin kişinin verisine ulaşamadım.`,
    bokyolu: `Gün içinde kullanım hakkınız dolduğu için işlem yapamadım.` 

}