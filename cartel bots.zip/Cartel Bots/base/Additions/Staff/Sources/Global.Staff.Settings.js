module.exports = {

    // Stat Sistemi Ayarları

    generalChatCategory: "1193231861674168416",

    musicRooms: ["1193231862194241627"],

    chatCategorys: [
        {id: "1193231861674168416", isim: []},
      
       

    ],

    voiceCategorys: [
        {id: "1193231862194241627", isim: []},
       
    ],

    // Upstaff Sistemi Ayarları

    sistemcik: true,
   
    accessPointChannels: ["970367905810235502","970367907513110688","970367912940548216","970367923820589139","970367928367190047","970367930044936273", "970367933849174016", "970367943210844190", "970367944792109088", "970367948214632539", "970367949644902540"],
    fullPointChannels: ["970367940811710505","970367938190266408","970367911136989234", "970367926848864286", "970367925460545566"],

points: {
    voice: 8,
    halfVoice: 2,
    invite: 1,
    message: 0.1,
    tagged:  30,
    staff:  45,
    record: 5,
    tasks:  10,
},


    staffs: [
        { rol: '1196897454180798485', exrol: [], Puan: 0, No: 0, Sorumluluk: 100},
        { rol: '1196897452620533880', exrol: [], Puan: 1000, No: 1, Sorumluluk: 200},
        { rol: '1196897450988941452', exrol: [], Puan: 2000, No: 2, Sorumluluk: 300},
        { rol: '1196897448711434280', exrol: [], Puan: 3000, No: 3, Sorumluluk: 400},
        { rol: '1196897447365070969', exrol: [], Puan: 4000, No: 4, Sorumluluk: 500},
        { rol: '1196897445402116219', exrol: [], Puan: 5000, No: 5, Sorumluluk: 600},
        { rol: '1196897444143829185', exrol: ["1196897438473138239"], Puan: 6000, No: 6, Sorumluluk: 700},
        { rol: '1196897436287909939', exrol: [], Puan: 7000, No: 7, Sorumluluk: 800},
        { rol: '1196897435281272852', exrol: [], Puan: 8000, No: 8, Sorumluluk: 900},
        { rol: '1196897433947484313', exrol: ["1196897432970219610", "1196897430592037074"], Puan: 9000, No: 9, Sorumluluk: 1000},
        { rol: '1201660195156267078', exrol: [], Puan: 10000, No: 10, Sorumluluk: 1100},
        { rol: '1196897424455762053', exrol: [], Puan: 11000, No: 11, Sorumluluk: 1200},
        { rol: '1196897423029719131', exrol: ["1196897421423280248"], Puan: 12000, No: 12, Sorumluluk: 1300},
           ]
}