const { Client, Message, MessageEmbed} = require("discord.js");
const { richEmbed } = require("../../../../base/Funksiyonlar/embed");
const Coins = require('../../../../database/Schemas/Client.Users');

module.exports = {
    name: "günlük",
    command: ["günlükcoin","maaş","daily"],
    aliases: "günlük",
    description: "24 Saatte bir belirli bir coin ödülü alırsınız.",
    category: "eco",
    uzantı: true,
    
   /**
   * @param {Client} client 
   */
  önClient: function (client) {

  },

   /**
   * @param {Client} client
   * @param {Message} message
   * @param {Array<String|Number>} args
   * @returns {Promise<void>}
   */

  komutClient: async function (client, message, args) {
    if(ayarlar.ekonomiSistem === false) return;
    let embed = new richEmbed()
    let cartelcim = message.guild.members.cache.get(message.member.id);
    let Hesap = await Coins.findById({_id: cartelcim.id}) 
        if(Hesap && Hesap.Daily) {
            let yeniGün = Hesap.Daily + (1*24*60*60*1000);
            if (Date.now() < yeniGün) {
                message.react(message.guild.emojiyiBul(emojiler.no_cartel) ? message.guild.emojiyiBul(emojiler.no_cartel).id : undefined)
                return message.reply(`${message.guild.emojiyiBul(emojiler.no_cartel)} Tekrardan günlük ödül alabilmen için **${kalanzaman(yeniGün)}** beklemen gerekiyor.`).then(x => {
setTimeout(() => {x.delete()}, 7500)
})
            }
        }
    let Günlük = Math.random();
    Günlük = Günlük*(5000-100);
    Günlük = Math.floor(Günlük)+100
    await Coins.updateOne({ _id: cartelcim.id }, { $set: { "Daily": Date.now() }, $inc: { "Coin": Günlük } }, {upsert: true})
    await message.react(message.guild.emojiyiBul(emojiler.onay_cartel) ? message.guild.emojiyiBul(emojiler.onay_cartel).id : undefined)
    await message.reply({content: `**Başarıyla günlük ödül aldınız!**
Alınan günlük ödülünüz: \`${Günlük.toFixed(0).replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,")} ${ayarlar.serverName} Parası\`
Yarın tekrardan gelirsen daha güzel ödüllerle seni karşılayacağım. ${message.guild.emojiyiBul(emojiler.onay_cartel)}`})
.then(mesaj => {
    setTimeout(() => {
        mesaj.delete()
    }, 12500);
})
   }
};