const { Client, Message, MessageEmbed} = require("discord.js");
const { richEmbed } = require("../../../../base/Funksiyonlar/embed");
const Coins = require('../../../../database/Schemas/Client.Users');

module.exports = {
    name: "zenginler",
    command: ["topcoin","top-coin","zenginlistesi"],
    aliases: "topcoin",
    description: "24 Saatte bir belirli bir coin ödülü alırsınız.",
    category: "eco",
    uzantı: true,
    
   /**
   * @param {Client} client 
   */
  önClient: function (client) {

  },

   /**
   * @param {Client} client
   * @param {Message} message
   * @param {Array<String|Number>} args
   * @returns {Promise<void>}
   */

  komutClient: async function (client, message, args) {
    if(ayarlar.ekonomiSistem === false) return;
    let embed = new richEmbed()
    let Zenginler = []
    let data = await Coins.find()
    data.map(x => {
        Zenginler.push({
          _id: x._id,
          Gold: x.Gold,
          Coin: x.Coin
        })
    })
    message.reply({embeds: [embed.açıklama(`Aşağıda ki sıralama altın ve para bazından **30** üye aşağıda listelenmektedir.

${Zenginler.sort((a,b) => {
      return Number((b.Gold * client.dovizAltın) + b.Coin) - Number((a.Gold * client.dovizAltın) + a.Coin)
    }).filter(x => message.guild.members.cache.get(x._id) && !sistem.Rooter.Users.includes(x._id) && !message.guild.members.cache.get(x._id).user.bot).slice(0, 30).map((x, index) => `\` ${index+1} \` ${x._id ? message.guild.members.cache.get(x._id) : `<@${x._id}>`} \` ${x.Coin.toFixed(0).replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,")} \` ${message.guild.emojiyiBul(emojiler.Görev.Para)} | \` ${x.Gold} \` ${message.guild.emojiyiBul(emojiler.Görev.Altın)} ${x._id == message.member.id ? `**(Siz)**` : ``}`).join("\n")}`)]}).then(x => {
      setTimeout(() => {
        x.delete().catch(err => {})
      }, 20000);
    })
   }
};