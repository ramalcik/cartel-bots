const { Client, Message, MessageEmbed} = require("discord.js");
const { richEmbed } = require("../../../../base/Funksiyonlar/embed");
const Coins = require('../../../../database/Schemas/Client.Users');
module.exports = {
    name: "removebalance",
    command: ["balremove","bal-remove","ballrev","coinsil"],
    aliases: "removebalance <Altın/Para> <@cartel/ID> <Miktar>",
    description: "",
    category: "eco",
    uzantı: true,
    
   /**
   * @param {Client} client 
   */
  önClient: function (client) {

  },

   /**
   * @param {Client} client
   * @param {Message} message
   * @param {Array<String|Number>} args
   * @returns {Promise<void>}
   */

  komutClient: async function (client, message, args) {
    if(ayarlar.ekonomiSistem === false) return;
    let embed = new richEmbed()
    let cartelcim = message.guild.members.cache.get(message.member.id);
    let Coin = 0
    if(!sistem.Rooter.Users && sistem.Rooter.Users.some(user => user.isim === message.member.user.username)) return message.reply(cevaplar.yetersiz)
    if(!args[0]) return message.reply(`Lütfen hangi birimden geri alacağını belirt. (Örn: \`${sistem.botSettings.Prefixs[0]}removebalance <Altın/Para> <@cartel/ID> <Miktar>\` )`).then(x => {
        message.react(message.guild.emojiyiBul(emojiler.no_cartel) ? message.guild.emojiyiBul(emojiler.no_cartel).id : undefined)
        setTimeout(() => {
            x.delete()
        }, 7500);
    });
    if(args[0] == "Para" || args[0] == "para") {
        Coin = await client.Economy.bakiyeGöster(cartelcim.id, 1)
        let Gönderilen = message.mentions.members.first() || message.guild.members.cache.get(args[1])
        if(!Gönderilen) return message.reply(`Geri almak istediğiniz bi üyeyi belirtin.`).then(x => {
            message.react(message.guild.emojiyiBul(emojiler.no_cartel) ? message.guild.emojiyiBul(emojiler.no_cartel).id : undefined)
            setTimeout(() => {
                x.delete()
            }, 7500);
        });
        let Miktar = Number(args[2]);
        if(isNaN(Miktar)) return message.reply(`Geri almak istediğiniz miktarı rakam olarak girin.`).then(x => {
            message.react(message.guild.emojiyiBul(emojiler.no_cartel) ? message.guild.emojiyiBul(emojiler.no_cartel).id : undefined)
            setTimeout(() => {
                x.delete()
            }, 7500);
        });
        Miktar = Miktar.toFixed(0);
        if(Miktar <= 0) return message.reply(`Geri alınacak rakam birden küçük veya sıfır olamaz.`).then(x => {
            message.react(message.guild.emojiyiBul(emojiler.no_cartel) ? message.guild.emojiyiBul(emojiler.no_cartel).id : undefined)
            setTimeout(() => {
                x.delete()
            }, 7500);
        });
        await client.Economy.bakiyeGüncelle(Gönderilen.id, Miktar, "remove", 1)
        await Coins.updateOne({_id: Gönderilen.id}, { $push: { "Transfers": { cartelcim: cartelcim.id, Tutar: Miktar, Tarih: Date.now(), Islem: "Havadan Giden Para" } }}, {upsert: true})
        await message.react(message.guild.emojiyiBul(emojiler.onay_cartel) ? message.guild.emojiyiBul(emojiler.onay_cartel).id : undefined)
        await message.channel.send({embeds: [embed.açıklama(`${message.guild.emojiyiBul(emojiler.onay_cartel)} ${Gönderilen} üyesine başarıyla \`${Miktar}\` ${ayarlar.serverName} Parasını geri aldın.`)]})
        return;
    } else if(args[0] == "Altın" || args[0] == "altın") {
        Coin = await client.Economy.bakiyeGöster(cartelcim.id, 0)
        let Gönderilen = message.mentions.members.first() || message.guild.members.cache.get(args[1])
        if(!Gönderilen) return message.reply(`Geri almak istediğiniz bi üyeyi belirtin.`).then(x => {
            message.react(message.guild.emojiyiBul(emojiler.no_cartel) ? message.guild.emojiyiBul(emojiler.no_cartel).id : undefined)
            setTimeout(() => {
                x.delete()
            }, 7500);
        });
        let Miktar = Number(args[2]);
        if(isNaN(Miktar)) return message.reply(`Geri almak istediğiniz miktarı rakam olarak girin.`).then(x => {
            message.react(message.guild.emojiyiBul(emojiler.no_cartel) ? message.guild.emojiyiBul(emojiler.no_cartel).id : undefined)
            setTimeout(() => {
                x.delete()
            }, 7500);
        });
        Miktar = Miktar.toFixed(0);
        if(Miktar <= 0) return message.reply(`Geri alınacak rakam birden küçük veya sıfır olamaz.`).then(x => {
            message.react(message.guild.emojiyiBul(emojiler.no_cartel) ? message.guild.emojiyiBul(emojiler.no_cartel).id : undefined)
            setTimeout(() => {
                x.delete()
            }, 7500);
        });
        await client.Economy.bakiyeGüncelle(Gönderilen.id, Miktar, "remove", 0)
        await Coins.updateOne({_id: Gönderilen.id}, { $push: { "Transfers": { cartelcim: cartelcim.id, Tutar: Miktar, Tarih: Date.now(), Islem: "Havadan Giden Altın" } }}, {upsert: true})
        await message.react(message.guild.emojiyiBul(emojiler.onay_cartel) ? message.guild.emojiyiBul(emojiler.onay_cartel).id : undefined)
        await message.channel.send({embeds: [embed.açıklama(`${message.guild.emojiyiBul(emojiler.onay_cartel)} ${Gönderilen} üyesine başarıyla \`${Miktar}\` ${message.guild.emojiyiBul(emojiler.Görev.Altın)} geri aldın.`)]})
        return;
    
    }
    return message.reply(`Lütfen hangi birimden geri alacağını belirt. (Örn: \`${sistem.botSettings.Prefixs[0]}removebalance <Altın/Para> <@cartel/ID> <Miktar>\` )`).then(x => {
        message.react(message.guild.emojiyiBul(emojiler.no_cartel) ? message.guild.emojiyiBul(emojiler.no_cartel).id : undefined)
        setTimeout(() => {
            x.delete()
        }, 7500);
    });
  }
};