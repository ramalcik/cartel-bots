const { Client, Message, MessageEmbed} = require("discord.js");
const Punitives = require('../../../../database/Schemas/Global.Punitives');
const Users = require('../../../../database/Schemas/Client.Users');
const { richEmbed } = require('../../../../base/Funksiyonlar/embed');
const getLimit = new Map();

module.exports = {
    name: "yargı",
    command: ["yargi","yargila","yargıla"],
    aliases: "yargı <@cartel/ID> <Sebep>",
    description: "Belirlenen üyeyi sunucudan uzaklaştırır.",
    category: "kurucu",
    uzantı: true,
    
   /**
   * @param {Client} client 
   */
  önClient: function (client) {

  },

   /**
   * @param {Client} client 
   * @param {Message} message 
   * @param {Array<String>} args 
   */

  komutClient: async function (client, message, args) {
    if (!(sistem.Rooter.Users && sistem.Rooter.Users.some(user => user.isim === message.member.user.username)) && message.guild.ownerId != message.member.id)  if(message.member.id != "719117042904727635") return message.channel.send({embeds: [new richEmbed().üstBaşlık(message.member.user.username, message.member.user.avatarURL({dynamic: true})).açıklama(cevaplar.yetersiz)]})
    if(!ayarlar && !roller && !roller.banHammer || !roller.üstYönetimRolleri || !roller.yönetimRolleri || !roller.kurucuRolleri || !roller.altYönetimRolleri) return message.reply(cevaplar.notSetup)
    
    let cartelcim = message.mentions.members.first() || message.guild.members.cache.get(args[0])
        let sunucudabul = message.mentions.members.first() || message.guild.members.cache.get(args[0])
    if(!cartelcim) return message.channel.send({embeds: [new richEmbed().üstBaşlık(message.member.user.username, message.member.user.avatarURL({dynamic: true})).açıklama(cevaplar.üye)]})
    if(message.author.id === cartelcim.id) return message.channel.send({embeds: [new richEmbed().üstBaşlık(message.member.user.username, message.member.user.avatarURL({dynamic: true})).açıklama(cevaplar.kendi)]})
    if(sunucudabul && sunucudabul.user.bot) return message.channel.send({embeds: [new richEmbed().üstBaşlık(message.member.user.username, message.member.user.avatarURL({dynamic: true})).açıklama(cevaplar.bot)]})
    if(sunucudabul && message.member.roles.highest.position <= sunucudabul.roles.highest.position) return message.channel.send({embeds: [new richEmbed().üstBaşlık(message.member.user.username, message.member.user.avatarURL({dynamic: true})).açıklama(cevaplar.yetkiust)]})
    if(sunucudabul && roller.Yetkiler.some(rolAra => sunucudabul.roles.cache.has(rolAra)) && !message.member.permissions.has('ADMINISTRATOR') && !roller.kurucuRolleri.some(rolAra => message.member.roles.cache.has(rolAra))) return message.channel.send({embeds: [new richEmbed().üstBaşlık(message.member.user.username, message.member.user.avatarURL({dynamic: true})).açıklama(cevaplar.yetkilinoban)]}); 
    if(getLimit.get(message.member.id) >= ayarlar.banLimit) return message.channel.send({embeds: [new richEmbed().üstBaşlık(message.member.user.username, message.member.user.avatarURL({dynamic: true})).açıklama(cevaplar.bokyolu)]}).then(s => setTimeout(() => s.delete().catch(err => {}), 7500));
    let sebep = args.splice(1).join(" ");
    if(!sebep) return message.channel.send({embeds: [new richEmbed().üstBaşlık(message.member.user.username, message.member.user.avatarURL({dynamic: true})).açıklama(cevaplar.yetersiz)]})
    if(sunucudabul) {
        cartelcim.removeStaff()
        cartelcim.dangerRegistrant()
        cartelcim.addPunitives(2, message.member, sebep, message)
        message.react(message.guild.emojiyiBul(emojiler.onay_cartel) ? message.guild.emojiyiBul(emojiler.onay_cartel).id : undefined)
    } else {
        let cezano = await Punitives.countDocuments()
        cezano = cezano == 0 ? 1 : cezano + 1;
        let ceza = new Punitives({ 
            No: cezano,
            Member: cartelcim.id,
            Staff: message.member.id,
            Type: "Yasaklama",
            Reason: sebep,
            Date: Date.now()
        })
        ceza.save().catch(err => {})
        let findedChannel = message.guild.kanalıBul("ban-log")
        if(findedChannel) findedChannel.send({embeds: [new richEmbed().altBaşlık(`Ceza Numarası: #${cezano}`,message.guild.name ? message.guild.iconURL({dynamic: true}) : cartelcim.avatarURL({dynamic: true})).açıklama(`${cartelcim.toString()} kişisi, ${tarihsel(Date.now())} tarihinde \`${sebep}\` nedeniyle ${message.member} tarafından yasaklandı.`)]})
        await message.channel.send({embeds: [ new richEmbed().üstBaşlık(cartelcim.user.username, cartelcim.user.avatarURL({dynamic: true})).açıklama(`${cartelcim.toString()} kişisi sunucudan yasaklandı.`)].altBaşlık(`Ceza numarası \`#${cezano}\``)})
        await message.guild.members.ban(cartelcim.id, { reason: `#${ceza.No} (${ceza.Reason})` }).catch(err => {})
        await Users.updateOne({ _id: message.member.id } , { $inc: { "Uses.Ban": 1 } }, {upsert: true})
          }
    if(Number(ayarlar.banLimit)) {
        if(!message.member.permissions.has('ADMINISTRATOR') && !sistem.Rooter.Users && sistem.Rooter.Users.some(user => user.isim === message.member.user.username) && !roller.kurucuRolleri.some(rolAra => message.member.roles.cache.has(rolAra))) {
            getLimit.set(`${message.member.id}`, (Number(getLimit.get(`${message.member.id}`) || 0)) + 1)
          
    }
}
}

}