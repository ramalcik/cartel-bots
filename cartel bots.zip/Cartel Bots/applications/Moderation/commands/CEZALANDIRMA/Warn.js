const { Client, Message, MessageEmbed} = require("discord.js");
const Punitives = require('../../../../database/Schemas/Global.Punitives');

module.exports = {
    name: "uyarı",
    command: ["warn"],
    aliases: "warn <@cartel/ID>",
    description: "Belirlenen üyeyi ceza şeklinde uyarır ve cezalarına işler.",
    category: "yönetim",
    uzantı: true,
    
   /**
   * @param {Client} client 
   */
  önClient: function (client) {

  },

   /**
   * @param {Client} client 
   * @param {Message} message 
   * @param {Array<String>} args 
   */

  komutClient: async function (client, message, args) {
        if(!roller.warnHammer.some(rolAra => message.member.roles.cache.has(rolAra)) && !roller.kurucuRolleri.some(rolAra => message.member.roles.cache.has(rolAra)) && !message.member.permissions.has('ADMINISTRATOR')) return message.channel.send({embeds: [new richEmbed().üstBaşlık(message.member.user.username, message.member.user.avatarURL({dynamic: true})).açıklama(cevaplar.yetersiz)]})
        let cartelcim = message.mentions.members.first() || message.guild.members.cache.get(args[0])
        if(!cartelcim) return message.channel.send({embeds: [new richEmbed().üstBaşlık(message.member.user.username, message.member.user.avatarURL({dynamic: true})).açıklama(cevaplar.üye)]})
        if(message.author.id === cartelcim.id) return message.channel.send({embeds: [new richEmbed().üstBaşlık(message.member.user.username, message.member.user.avatarURL({dynamic: true})).açıklama(cevaplar.kendi)]})
        if(!cartelcim && message.member.roles.highest.position <= cartelcim.roles.highest.position) return message.channel.send({embeds: [new richEmbed().üstBaşlık(message.member.user.username, message.member.user.avatarURL({dynamic: true})).açıklama(cevaplar.yetkiust)]})
        let sebep = args.splice(1).join(" ");
        if(!sebep) return message.channel.send({embeds: [new richEmbed().üstBaşlık(message.member.user.username, message.member.user.avatarURL({dynamic: true})).açıklama(cevaplar.sebep)]})
        let lastWarn = await Punitives.find({Member: cartelcim.id, Type: "Uyarılma"})
        let checkRoles = [...roller.Yetkiler, ...roller.jailHammer, ...roller.üstYönetimRolleri, ...roller.yönetimRolleri,...roller.altYönetimRolleri, ...roller.kurucuRolleri]
        if(!checkRoles.some(x => cartelcim.roles.cache.has(x)) && !cartelcim.permissions.has("ADMINISTRATOR") && lastWarn.length >= 3) {
            if(roller.jailHammer.some(rolAra => message.member.roles.cache.has(rolAra)) || roller.üstYönetimRolleri.some(rolAra => message.member.roles.cache.has(rolAra)) || roller.altYönetimRolleri.some(rolAra => message.member.roles.cache.has(rolAra)) || roller.kurucuRolleri.some(rolAra => message.member.roles.cache.has(rolAra)) || roller.yönetimRolleri.some(rolAra => message.member.roles.cache.has(rolAra))  || message.member.permissions.has('ADMINISTRATOR')) {
                if(Number(ayarlar.jailLimit) && client.fetchJailLimit.get(message.member.id) >= ayarlar.jailLimit) return await cartelcim.addPunitives(6, message.member, sebep, message),message.react(message.guild.emojiyiBul(emojiler.onay_cartel) ? message.guild.emojiyiBul(emojiler.onay_cartel).id : undefined)
                cartelcim.dangerRegistrant() 
                return cartelcim.addPunitives(3, message.member, "Gereğinden fazla uyarı cezası bulunmak!" + ` (${sebep})`, message) 
            }
        }
        await cartelcim.addPunitives(6, message.member, sebep, message)
        message.react(message.guild.emojiyiBul(emojiler.onay_cartel) ? message.guild.emojiyiBul(emojiler.onay_cartel).id : undefined)

    }
};


